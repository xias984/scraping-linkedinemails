📘 Come usare ScrapingApp

1️⃣ Per prima cosa, esegui il file:
   setup_env.bat
   👉 Serve per installare Python localmente e preparare l'ambiente

2️⃣ Dopo il primo setup, lancia:
   run_app.bat
   👉 Si aprirà l'applicazione con interfaccia

🧼 Se vuoi eliminare tutto e ricominciare:
   esegui clean_all.bat

💡 Tutto funziona senza installare nulla nel sistema.
